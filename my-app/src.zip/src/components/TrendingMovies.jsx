"use client"

import MovieSection from "./MovieSection"

export default function TrendingMovies({ movies }) {
  return <MovieSection title="Trending Movies" movies={movies} />
}

